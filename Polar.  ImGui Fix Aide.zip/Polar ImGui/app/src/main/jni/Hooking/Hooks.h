#ifndef HOOKS
#define HOOKS
namespace Hooks // place your hooks in this file to keep everything neat and tidy
{

}
#endif HOOKS